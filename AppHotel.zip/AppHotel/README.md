# App Hotel

App Hotel é um aplicativo de exemplo desenvolvido em .NET MAUI para estudo de BindingContext, DatePicker, Picker e Stepper.

## Estrutura
- App.xaml / App.xaml.cs
- MainPage.xaml / MainPage.xaml.cs
- SobrePage.xaml / SobrePage.xaml.cs
- ViewModels/ReservaViewModel.cs
- Capturas/ (coloque aqui os screenshots da tela Sobre)

## Como abrir
Abra a solução no Visual Studio 2022 (com workload .NET MAUI) e execute no emulador ou no Windows.

## Desenvolvedor
Filipe Pina Martins Costa — 2025
